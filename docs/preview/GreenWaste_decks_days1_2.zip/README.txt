GreenWaste: eleven course-owned sessions, October 2026
Three downloads: print materials, decks Days 1-2, decks Days 3-4. Unzip both deck archives to the same folder.
Days 1-3: 60/60/75 minutes. Day 4: 60/60 minutes.
The final Day 4 evaluation simulation is prepared by another provider and excluded.

ParticipantSheets: print each two-page sheet double-sided, one per person.
TrainerPacks: separate keys, cards and distribution instructions; keep keys private.
References: Session 1 Day 4 report has deliberate flaws; use the corrected Session 2 findings when writing.
Optional rating sheet duplicates the Session 1 worksheet; optional brief template duplicates Session 2 Sheet 1.
Posters: four files, five A1 landscape sheets; Day 4 wall is two sheets.
Classroom brief specifies group allocations, copies and cutting.

Decks: open the HTML decks in a browser. Browser R trainer demos require internet and access to the corrected CSV; rehearse on the venue network. Embedded teaching assets are bundled, the external R runtime is not. Printed results are the fallback.
RoomTool: follow ROOM_POLL_README.md; Python standard library server, no accounts or paid service. Rehearse facilitator-to-phone network access; labelled cards are the fallback.
All figures are fictional training data. The individual reading check is a teaching check, not validated certification.
