GreenWaste Module 2: current teaching versions, 11 October 2026

Use the eleven teaching decks and matching worksheets in this package.
Canonical online guide: https://3ie.academy/teaching_materials
Follow each deck's embedded trainer script and timings (press S for speaker view).
Do not use the older Word packs or October 6 classroom brief for revised sessions.

Day 1 Sessions 1 and 3 intentionally retain Fiona's worksheet-aligned hybrids
and the original printed two-page worksheets and printed packs.
Day 1 Session 2 uses the revised seven-page Word worksheet. Coordinate with Fiona
if the old sheets were printed: its hybrid/flex alternatives are not selected here.

All other worksheets are printable HTML. Open in a browser and use Print worksheet
at A4. One worksheet per participant. Additional cards/reports are separate pages:
Day 2 Session 1: 6 worksheet pages; H4-A included.
Day 2 Session 2: 6 worksheet pages; 8 group cards plus number line (9 pages).
Day 2 Session 3: 6 worksheet pages; profile/cost cards (2 pages), reveal costs later.
Day 3 Session 1: 6 worksheet pages; 5 scenario cards, board and results (7 pages).
  Give one scenario per group; distribute the results page only after predictions.
Day 3 Session 2: 7 worksheet pages.
Day 3 Session 3: 8 worksheet pages; question bank (2 pages) after independent work;
  evidence pack (5 pages) for the analyst's role, not an advance answer handout.
Day 4 Session 1: 5 worksheet pages; flawed report (4 pages); private trainer key
  (5 pages). The two A1 wall sheets are not worksheet pages.
Day 4 Session 2: 7 worksheet pages; corrected findings (2 pages); targeted retries
  (3 pages), distributed after feedback; private trainer key (4 pages).
Use corrected findings for drafting, not the earlier flawed report.

ParticipantSheets contains worksheets and separately labelled participant/source
materials. TrainerPacks contains private keys. Keep keys private. Posters retains
the four existing A1 poster files. Follow the deck notes for cutting/group allocation.
Use the AI good-practice card beside the AI tasks.

Deck archives: unzip both into the same folder. Open the HTML decks in a browser.
R trainer demos require internet for webR and the bundled GreenWaste CSV. Rehearse
on the venue network. The external R runtime is not bundled; printed results are
the fallback. RoomTool instructions remain in ROOM_POLL_README.md.
The final Day 4 simulation is supplied separately and is not a twelfth deck.
All records and scenarios are fictional training data.