GreenWaste Module 2: print materials, 12 October 2026

Use the eleven teaching decks and matching worksheets in this package.
Canonical online guide: https://3ie.academy/teaching_materials
Follow each deck's embedded trainer script and timings (press S for speaker view).

All participant worksheets, cards and source documents are print-ready A4 PDFs
(Day 1 Sessions 1 and 3 and the Day 1 Session 2 Word version are .docx).
Print one worksheet per participant. Additional cards/reports are separate files:
Day 1 Session 1: 2-page worksheet (Word) and AI handout (2 pages).
Day 1 Session 2: 7-page worksheet (PDF or Word); 4 decision cards plus board (5 pages).
Day 1 Session 3: 2-page worksheet (Word) and AI handout (2 pages).
Day 2 Session 1: 6 worksheet pages; H4-A included.
Day 2 Session 2: 6 worksheet pages; 8 group cards plus number line (9 pages).
Day 2 Session 3: 6 worksheet pages; profile/cost cards (2 pages), reveal costs later.
Day 3 Session 1: 6 worksheet pages; 5 scenario cards, board and results (7 pages).
  Give one scenario per group; distribute the results page only after predictions.
Day 3 Session 2: 7 worksheet pages.
Day 3 Session 3: 8 worksheet pages; question bank (2 pages) after independent work;
  evidence pack (4 pages) for the analyst's role, not an advance answer handout.
Day 4 Session 1: 5 worksheet pages; report for reading (4 pages).
Day 4 Session 2: 7 worksheet pages; corrected findings (2 pages); targeted retries
  (3 pages), distributed after feedback.
Use corrected findings for drafting, not the earlier flawed report.

Trainer keys are NOT included in this package. Posters retains the four A1 poster
files. Use the AI good-practice card (AI_good_practice_review.pdf) beside the AI tasks.
Follow the deck notes for cutting/group allocation.

Deck archives: unzip both into the same folder. Open the HTML decks in a browser.
R trainer demos require internet for webR and the bundled GreenWaste CSV. Rehearse
on the venue network. The external R runtime is not bundled; printed results are
the fallback. RoomTool instructions remain in ROOM_POLL_README.md.
The final Day 4 simulation is supplied separately and is not a twelfth deck.
All records and scenarios are fictional training data.

SEPARATE PRINTS (hand out later, not with the main set):
- Day 2 S3: profile cards (Oct13_session3_review_cards_profiles.pdf) first; reveal slips only after pairs record their choices.
- Day 3 S1: scenario cards and board (pages 1-6); the results table is a separate print, shown only after groups record predictions.
- Day 3 S3: question bank after independent work; evidence pack for the analyst only.
- Day 4 S2: retry cards only for participants who need them, after feedback.
